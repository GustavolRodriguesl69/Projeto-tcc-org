
</html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>replit</title>
  <link href="CSS/fontes.css" rel="stylesheet" type="text/css" />
  <link href="CSS/login.css" rel="stylesheet" type="text/css" />
</head>

<body>
<main>
  <div class="login_logo_container">
    <span class="login_logo"> Drip <br> Culture </span>
  </div>
  <form action="PHP/cadastro.php" method="POST">
    <label for="email">Email</label>
    <input type="text" id="email" name="email">
    <label for="usuario">Usuário</label>
    <input type="text" id="usuario" name="usuario">
    <label for="senha">Senha</label>
    <input type="text" id="senha" name="senha">
    <label for="endereco">Endereço</label>
    <input type="text" id="endereco" name="endereco">
    <button type="submit">Cadastrar</button>
  </form>
</main>
</body>

</html>