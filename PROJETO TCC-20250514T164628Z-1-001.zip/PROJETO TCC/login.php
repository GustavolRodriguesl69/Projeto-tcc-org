<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>replit</title>
  <link href="CSS/fontes.css" rel="stylesheet" type="text/css" />
  <link href="CSS/login.css" rel="stylesheet" type="text/css" />
</head>

<body>
<main>
  <div class="login_logo_container">
    <span class="login_logo"> Drip <br> Culture </span>
  </div>
  <form action="PHP/login.php" method="POST">
    <label for="email">Email</label>
    <input type="text" id="email" name="email">
    <label for="senha">Senha</label>
    <input type="text" id="senha" name="senha">
    <a href="./cadastro.php">Não tem uma conta?</a>
    <button type="submit">Login</button>
  </form>
</main>
</body>

</html>